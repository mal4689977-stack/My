<!-- Навигационные карточки -->
<section class="nav-cards-section">
    <div class="nav-cards-grid">
        <a href="../pages/catalog/beaches.php" class="nav-card">
            <i class="fas fa-umbrella-beach"></i>
            <span>Пляжи</span>
        </a>
        <a href="../pages/catalog/housing.php" class="nav-card">
            <i class="fas fa-bed"></i>
            <span>Жилье</span>
        </a>
        <a href="../pages/catalog/entertainment.php" class="nav-card">
            <i class="fas fa-hiking"></i>
            <span>Активный отдых</span>
        </a>
        <a href="../pages/catalog/tours.php" class="nav-card">
            <i class="fas fa-binoculars"></i>
            <span>Экскурсии</span>
        </a>
        <a href="../pages/catalog/restaurants.php" class="nav-card">
            <i class="fas fa-utensils"></i>
            <span>Рестораны</span>
        </a>
        <a href="../pages/catalog/transport.php" class="nav-card">
            <i class="fas fa-bus"></i>
            <span>Транспорт</span>
        </a>
    </div>
</section>