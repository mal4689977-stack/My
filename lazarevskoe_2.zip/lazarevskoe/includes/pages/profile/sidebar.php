<!-- Боковая панель - НА МОБИЛЬНЫХ БУДЕТ СВЕРХУ -->
<div class="profile-sidebar">
    <div class="profile-avatar">
        <img src="https://via.placeholder.com/150" alt="Аватар">
        <div class="profile-name">Иван Иванов</div>
        <div class="profile-location">Лазаревское, Сочи</div>
    </div>

    <div class="profile-stats">
        <div class="stat-item">
            <span class="stat-number">12</span>
            <span class="stat-label">Объявления</span>
        </div>
        <div class="stat-item">
            <span class="stat-number">47</span>
            <span class="stat-label">Избранное</span>
        </div>
        <div class="stat-item">
            <span class="stat-number">4.8</span>
            <span class="stat-label">Рейтинг</span>
        </div>
    </div>

    <div class="profile-actions">
        <button class="profile-btn">
            <i class="fas fa-edit"></i> Редактировать профиль
        </button>
        <button class="profile-btn">
            <i class="fas fa-cog"></i> Настройки
        </button>
        <button class="profile-btn secondary">
            <i class="fas fa-plus-circle"></i> Добавить объявление
        </button>
    </div>
</div>