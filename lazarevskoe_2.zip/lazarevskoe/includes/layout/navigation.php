<!-- Нижняя навигация -->
<div class="nav-cards-grid-bottom">
    <button class="nav-card-bottom" onclick="window.location.href='../pages/catalog/housing.php'">
        <i class="fas fa-bed"></i>
        <span>Жилье</span>
    </button>
    <button class="nav-card-bottom" onclick="window.location.href='../index.php'">
        <i class="fas fa-home"></i>
        <span>Главное</span>
    </button>
    <button class="nav-card-bottom" onclick="window.location.href='../pages/profile/index.php'">
        <i class="fas fa-user"></i>
        <span>Профиль</span>
    </button>
    <button class="nav-card-bottom" onclick="window.location.href='../pages/profile/favorites.php'">
        <i class="fas fa-heart"></i>
        <span>Избранное</span>
    </button>
    <button class="nav-card-bottom" onclick="window.location.href='../pages/ads/create.php'">
        <i class="fas fa-plus"></i>
        <span>Добавить</span>
    </button>
</div>