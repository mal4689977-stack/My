<?php 
$page_title = "Профиль - Лазаревское";
include 'includes/layout/header.php';
include 'includes/layout/utility-bar.php';
?>

<!-- Заголовок профиля -->
<div class="profile-header">
    <h1>Мой профиль</h1>
    <p>Управляйте своими объявлениями и настройками</p>
</div>

<!-- Основной контент -->
<div class="profile-content">
    <?php include 'includes/pages/profile/sidebar.php'; ?>

    <!-- Основная секция - НА МОБИЛЬНЫХ БУДЕТ СНИЗУ -->
    <div class="profile-main">
        <?php 
        include 'includes/pages/profile/ads.php';
        include 'includes/pages/profile/favorites.php';
        ?>
    </div>
</div>

<?php include 'includes/layout/footer.php'; ?>